
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { name: '18-25', residents: 5 },
  { name: '26-35', residents: 10 },
  { name: '36-50', residents: 7 },
  { name: '51+', residents: 3 },
];

export default function AnalyticsChart() {
  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="residents" fill="#7c3aed" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
