
const residents = [
  { id: 1, name: 'John Doe', age: 30, address: 'Street 1', contact: '1234567890' },
  { id: 2, name: 'Jane Smith', age: 45, address: 'Street 2', contact: '0987654321' },
];

export default function DataTable() {
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full bg-white">
        <thead>
          <tr>
            <th className="py-2 px-4 border">ID</th>
            <th className="py-2 px-4 border">Name</th>
            <th className="py-2 px-4 border">Age</th>
            <th className="py-2 px-4 border">Address</th>
            <th className="py-2 px-4 border">Contact</th>
          </tr>
        </thead>
        <tbody>
          {residents.map((res) => (
            <tr key={res.id}>
              <td className="py-2 px-4 border">{res.id}</td>
              <td className="py-2 px-4 border">{res.name}</td>
              <td className="py-2 px-4 border">{res.age}</td>
              <td className="py-2 px-4 border">{res.address}</td>
              <td className="py-2 px-4 border">{res.contact}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
