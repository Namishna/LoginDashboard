
import DataTable from './DataTable';
import AnalyticsChart from './AnalyticsChart';

export default function Dashboard() {
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Admin Dashboard</h1>
      <DataTable />
      <h2 className="text-2xl font-semibold mt-8">Analytics</h2>
      <AnalyticsChart />
    </div>
  );
}
